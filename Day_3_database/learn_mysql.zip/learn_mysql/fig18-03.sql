SELECT productID, productName
FROM products
LIMIT 3;

SELECT productID, productName
FROM products
LIMIT 0 , 3;

SELECT productID, productName
FROM products
LIMIT 1, 3;
